const stars = document.querySelectorAll(".star");
for (let i = 0; i < stars.length; i++) {
    stars[i].addEventListener("click", handleStarClick);
}

function handleStarClick(event) {
    for (let i = 0; i < stars.length; i++) {
        stars[i].classList.remove("active");
    }

    const clickedStar = event.target;
    let rating = clickedStar.getAttribute("rating");

    for (let i = 0; i < rating; i++) {
        stars[i].classList.add("active");
    }
    document.getElementById("rate").innerHTML = rating
}